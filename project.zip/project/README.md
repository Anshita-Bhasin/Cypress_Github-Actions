# Install Cypress (Node version should be 12 and above)
1. npm init
2. npm install cypress --save-dev

# Run Cypress Test Locally

1. npx cypress open

# Configure and Run Cypress Test Case On LambdaTest Platform

1. npm install -g lambdatest-cypress-cli
2. lambdatest-cypress init
3. lambdatest-cypress run
